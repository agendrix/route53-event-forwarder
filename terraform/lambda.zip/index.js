"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.__test__ = void 0;
const aws_sdk_1 = __importDefault(require("aws-sdk"));
const handler = async (event) => {
    var _a, _b, _c, _d;
    const eventBridge = new aws_sdk_1.default.EventBridge(({ region: process.env.REGION }));
    const params = { Entries: [formatEvent(event)] };
    const response = await eventBridge.putEvents(params).promise();
    if (response.FailedEntryCount !== 0) {
        throw new Error(`An error occurred while forwarding event ${event.id}. Error code: ${(_b = (_a = response.Entries) === null || _a === void 0 ? void 0 : _a.shift()) === null || _b === void 0 ? void 0 : _b.ErrorCode}, Error message: ${(_d = (_c = response.Entries) === null || _c === void 0 ? void 0 : _c.shift()) === null || _d === void 0 ? void 0 : _d.ErrorMessage}`);
    }
};
const formatEvent = (event) => {
    var _a, _b, _c, _d, _e;
    const recordName = (_e = (_d = (_c = (_b = (_a = event.detail) === null || _a === void 0 ? void 0 : _a.requestParameters) === null || _b === void 0 ? void 0 : _b.changeBatch) === null || _c === void 0 ? void 0 : _c.changes[0]) === null || _d === void 0 ? void 0 : _d.resourceRecordSet) === null || _e === void 0 ? void 0 : _e.name;
    if (recordName)
        event.detail.requestParameters.recordName = recordName;
    return ({
        Source: process.env['EVENT_SOURCE'],
        Time: event.time,
        Resources: event.resources,
        DetailType: event['detail-type'],
        Detail: JSON.stringify(event.detail)
    });
};
exports.handler = handler;
exports.__test__ = {
    handler,
    formatEvent
};
