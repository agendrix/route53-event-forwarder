"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.__test__ = void 0;
const aws_sdk_1 = __importDefault(require("aws-sdk"));
const handler = async (event) => {
    var _a, _b, _c, _d, _e, _f;
    const eventBridge = new aws_sdk_1.default.EventBridge(({ region: process.env.REGION }));
    const params = { Entries: [formatEvent(event)] };
    const response = await eventBridge.putEvents(params).promise();
    if (response.FailedEntryCount === 0) {
        console.log(`Event ${event.id} successfully forwarded to region ${process.env.REGION}. New event id: ${(_b = (_a = response.Entries) === null || _a === void 0 ? void 0 : _a.shift()) === null || _b === void 0 ? void 0 : _b.EventId}`);
    }
    else {
        throw new Error(`An error occurred while forwarding event ${event.id}. Error code: ${(_d = (_c = response.Entries) === null || _c === void 0 ? void 0 : _c.shift()) === null || _d === void 0 ? void 0 : _d.ErrorCode}, Error message: ${(_f = (_e = response.Entries) === null || _e === void 0 ? void 0 : _e.shift()) === null || _f === void 0 ? void 0 : _f.ErrorMessage}`);
    }
};
const formatEvent = (event) => {
    var _a, _b, _c, _d, _e;
    const recordName = (_e = (_d = (_c = (_b = (_a = event.detail) === null || _a === void 0 ? void 0 : _a.requestParameters) === null || _b === void 0 ? void 0 : _b.changeBatch) === null || _c === void 0 ? void 0 : _c.changes[0]) === null || _d === void 0 ? void 0 : _d.resourceRecordSet) === null || _e === void 0 ? void 0 : _e.name;
    if (recordName)
        event.detail.requestParameters.recordName = recordName;
    return ({
        Source: process.env['EVENT_SOURCE'],
        Time: event.time,
        Resources: event.resources,
        DetailType: event['detail-type'],
        Detail: JSON.stringify(event.detail)
    });
};
exports.handler = handler;
exports.__test__ = {
    handler,
    formatEvent
};
